import turtle

PIXEL_SIZE = 30
ROWS = 20
COLUMNS = 20

turta = turtle

def init():
    turta.reset()
    turta.speed(0)
    turta.penup()
    turta.pencolor('black')
    turta.fillcolor('white')
    turta.goto(-PIXEL_SIZE * ROWS / 2, PIXEL_SIZE * COLUMNS / 2)

# Part 1: Function to get color by code
def get_color(code):
    if code == "0":
        return 'black'
    elif code == "1":
        return 'white'
    elif code == "2":
        return 'red'
    elif code == "3":
        return 'yellow'
    elif code == "4":
        return 'orange'
    elif code == "5":
        return 'green'
    elif code == "6":
        return 'yellowgreen'
    elif code == "7":
        return 'sienna'
    elif code == "8":
        return 'tan'
    elif code == "9":
        return 'gray'
    elif code == "A":
        return 'darkgray'
    else:
        return None  # Invalid color

# Part 2: Draw a single pixel of a specific color
def draw_color_pixel(color, turta):
    turta.speed(0)
    turta.color(color)
    turta.pendown()
    turta.begin_fill()
    
    for _ in range(4):
        turta.forward(PIXEL_SIZE)
        turta.right(90)
    
    turta.end_fill()
    turta.color("black")
    
    for _ in range(4):
        
        turta.forward(PIXEL_SIZE)
        turta.right(90)

    turta.penup()
    turta.forward(PIXEL_SIZE)
    turta.pendown()

# Modified draw_pixel to use draw_color_pixel
def draw_pixel(code, turta):
    color = get_color(code)
    if color:
        draw_color_pixel(color, turta)
    else:
        print(f"Invalid color code: {code}")

# Part 3: Function to draw a line of pixels based on a string of color codes
def draw_line_from_string(color_string, turta):
    for code in color_string:
        if get_color(code) is None:
            print(f"Invalid color code encountered: {code}")
            return False
        draw_pixel(code, turta)
    return True

# Function to move to the next row
def next_row():
    turta.penup()
    turta.goto(-PIXEL_SIZE * COLUMNS / 2, turta.ycor() - PIXEL_SIZE)
    turta.pendown()

# Part 4: Function to draw multiple lines from user input
def draw_shape_from_string(turta):
    while True:
        color_string = input("Enter a line of color codes (or leave empty to stop): ")
        if color_string == "":
            break
        if not draw_line_from_string(color_string, turta):
            print("Stopping due to invalid color code.")
            break
        next_row()

# Part 5: Function to read from a file and draw the image
def draw_shape_from_file(turta):
    file_path = input("Enter the path of the file to read: ")
    
    try:
        with open(file_path, 'r') as file:
            for line in file:
                color_string = line.strip()  # Remove any extra whitespace or newlines
                if not draw_line_from_string(color_string, turta):
                    print("Stopping due to invalid color code.")
                    break
                next_row()
    except FileNotFoundError:
        print(f"File {file_path} not found.")

# Part 6: Draw a grid (checkerboard pattern) without using a list
def draw_grid(turta):
    init()  # Initialize turtle
    for row in range(ROWS):
        color_string = ""
        for col in range(COLUMNS):
            # Alternate between '0' (black) and '1' (white) based on position
            if (row + col) % 2 == 0:
                color_string += "0"
            else:
                color_string += "2"
        draw_line_from_string(color_string, turta)
        next_row()

def main():
    init()  # Initialize the turtle window
    choice = input("Press 1 to enter color strings, 2 to read from a file, 3 to draw a grid: ")
    
    if choice == "1":
        draw_shape_from_string(turta)
    elif choice == "2":
        draw_shape_from_file(turta)
    elif choice == "3":
        draw_grid(turta)
    
    turta.exitonclick()

if __name__ == "__main__":
    main()
